# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from ackermann_msgs.msg import AckermannDriveStamped


class Relay(Node):

    def __init__(self):
        super().__init__('Relay')
        self.subscription = self.create_subscription(AckermannDriveStamped, 'drive', self.listener_callback, 10)
        self.subscription  # prevent unused variable warning

        self.publisher_ = self.create_publisher(AckermannDriveStamped, 'drive_relay', 10)


    def listener_callback(self, msg):
        self.get_logger().info('I heard: "%s"' % msg.drive)
        v = msg.drive.speed
        d = msg.drive.steering_angle

        #adiciona no log
        self.get_logger().info(f'Received: speed={v}, steering_angle={d}')

        # Multiplicar por 3
        new_v = v * 3
        new_d = d * 3

        # Criar a nova mensagem com os valores modificados
        new_msg = AckermannDriveStamped()
        new_msg.drive.speed = new_v
        new_msg.drive.steering_angle = new_d

        # Publicar a nova mensagem no tópico 'drive_relay'
        self.publisher_.publish(new_msg)
        self.get_logger().info(f'Relayed: speed={new_v}, steering_angle={new_d}')

        


def main(args=None):
    rclpy.init(args=args)

    relay = Relay()
    rclpy.spin(relay)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    relay.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
