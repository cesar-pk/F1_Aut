# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from ackermann_msgs.msg import AckermannDriveStamped


class Talker(Node):

    def __init__(self):
        super().__init__('Talker')

        # Declarar parâmetros
        self.declare_parameter('v', 1.0)  # velocidade
        self.declare_parameter('d', 1.0)  # ângulo de direção

        #self.publisher_ = self.create_publisher(String, 'drive', 10)
        self.publisher_ = self.create_publisher(AckermannDriveStamped, 'drive', 10)

        self.timer = self.create_timer(0.1, self.publish_message)

    def publish_message(self):        
        v = self.get_parameter('v').get_parameter_value().double_value
        d = self.get_parameter('d').get_parameter_value().double_value

        # Criar a mensagem
        msg = AckermannDriveStamped()
        msg.drive.speed = v
        msg.drive.steering_angle = d

        # Publicar a mensagem
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: speed={v}, steering_angle={d}')


def main(args=None):
    rclpy.init(args=args)

    talker = Talker()
    
    rclpy.spin(talker)  # Usamos spin para o nó ficar ativo enquanto o timer executa

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    talker.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
