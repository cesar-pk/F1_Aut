def main():
    print('Hi from lab1_pkg.')


if __name__ == '__main__':
    main()
